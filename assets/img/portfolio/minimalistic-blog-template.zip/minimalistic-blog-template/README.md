# Minimalistic blog template

A Pen created on CodePen.io. Original URL: [https://codepen.io/IzacLLd/pen/VwEJmme](https://codepen.io/IzacLLd/pen/VwEJmme).

